import customtkinter as ctk
from tkinter import messagebox
from PIL import Image
import sqlite3
from datetime import datetime
import csv
from tkinter import filedialog
from tkcalendar import DateEntry
from datetime import datetime


class FinTrack:
    def __init__(self, user_id= None):
        self.current_user_id = user_id  
        ctk.set_appearance_mode("light")
        ctk.set_default_color_theme("green")
        

        self.root = ctk.CTk()
        self.root.geometry('1200x700+150+50')
        self.root.title('FinTrack Dashboard')

        self.database_setup()

        self.main_container = ctk.CTkFrame(self.root, fg_color="#ffffff")
        self.main_container.pack(fill="both", expand=True)

        self.create_sidebar()
        self.create_main_content()

        self.show_dashboard()

    def database_setup(self):
        self.conn = sqlite3.connect("fintrack.db")
        self.cursor = self.conn.cursor()
        
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                type TEXT NOT NULL,
                category TEXT NOT NULL,
                amount REAL NOT NULL,
                description TEXT,
                date DATE NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        """)

        self.conn.commit()

    def create_sidebar(self):
        self.sidebar = ctk.CTkFrame(self.main_container, fg_color="#f0f0f0", width=250)
        self.sidebar.pack(side="left", fill="y", padx=0, pady=0)

        try:
            self.logo = ctk.CTkImage(Image.open('img\\logo.png'), size=(120, 120))
            ctk.CTkLabel(self.sidebar, image=self.logo, text="").pack(pady=(30, 20))
        except:
            ctk.CTkLabel(self.sidebar, text="FinTrack", font=("Helvetica", 20, "bold")).pack(pady=(30, 20))

        nav_buttons = [
            ("Dashboard", self.show_dashboard),
            ("Income", self.show_income),
            ("Expenses", self.show_expense),
            ("Budget", self.show_budget),
            ("Export to CSV File", self.export_to_csv),
            ("Edit Profile", self.show_edit_profile_form)
        ]

        for text, command in nav_buttons:
            ctk.CTkButton(
                self.sidebar,
                text=text,
                font=("Helvetica", 14),
                fg_color="transparent",
                text_color="#2d2d2d",
                hover_color="#e0e0e0",
                anchor="w",
                width=200,
                height=40,
                command=command
            ).pack(pady=5, padx=20)

        ctk.CTkLabel(self.sidebar, text="", height=20).pack(fill="y", expand=True)

        self.username = self.get_username()

        try:
            self.user_icon = ctk.CTkImage(Image.open('img\\user.png'), size=(50, 50))
        except:
            self.user_icon = None

        user_frame = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        user_frame.pack(pady=(10, 10))

        if self.user_icon:
            ctk.CTkLabel(user_frame, image=self.user_icon, text="").pack(side="left", padx=5)

        self.username_label = ctk.CTkLabel(user_frame, text=self.username, font=("Helvetica", 14, "bold"))
        self.username_label.pack(side="left", padx=5)


        ctk.CTkButton(
            self.sidebar,
            text="Logout",
            font=("Helvetica", 14),
            fg_color="#66785F",
            text_color="#ffffff",
            hover_color="#4a5745",
            width=200,
            height=40,
            command=self.logout
        ).pack(side="bottom", pady=20, padx=20)

    def get_username(self):
        if not self.current_user_id:
            return "Guest"
        
        self.cursor.execute("SELECT name FROM users WHERE id = ?", (self.current_user_id,))
        user = self.cursor.fetchone()
        return user[0] if user else "Guest"


    def create_main_content(self):
        self.content = ctk.CTkFrame(self.main_container, fg_color="#ffffff")
        self.content.pack(side="right", fill="both", expand=True, padx=20, pady=20)

    def get_transactions_summary(self):
        if not self.current_user_id:
            return {"total_income": 0, "total_expense": 0, "total_balance": 0}
        
        self.cursor.execute("""
            SELECT 
                COALESCE(SUM(CASE WHEN type = 'income' THEN amount ELSE 0 END), 0) as total_income,
                COALESCE(SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END), 0) as total_expense
            FROM transactions
            WHERE user_id = ?
        """, (self.current_user_id,))
        income, expense = self.cursor.fetchone()
        return {
            "total_income": income,
            "total_expense": expense,
            "total_balance": income - expense
        }

    def format_amount(self, amount):
        return f"Rs. {amount:,.2f}"

    
    def create_transaction_row(self, parent, transaction, show_type=True):
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=20, pady=5)
        
        ctk.CTkLabel(
            row,
            text=transaction['date'],
            font=("Helvetica", 12),
            text_color="#2d2d2d"
        ).pack(side="left", expand=True)
        
        ctk.CTkLabel(
            row,
            text=transaction['category'],
            font=("Helvetica", 12),
            text_color="#2d2d2d"
        ).pack(side="left", expand=True)
        
        if show_type:
            ctk.CTkLabel(
                row,
                text=transaction['type'].title(),
                font=("Helvetica", 12),
                text_color="#2d2d2d"
            ).pack(side="left", expand=True)
        
        ctk.CTkLabel(
            row,
            text=transaction['description'],
            font=("Helvetica", 12),
            text_color="#2d2d2d"
        ).pack(side="left", expand=True)
        
        amount_color = "#4CAF50" if transaction['type'] == 'income' else "#F44336"
        ctk.CTkLabel(
            row,
            text=self.format_amount(transaction['amount']),
            font=("Helvetica", 12, "bold"),
            text_color=amount_color
        ).pack(side="left", expand=True)
        
        if not show_type:
            actions_frame = ctk.CTkFrame(row, fg_color="transparent")
            actions_frame.pack(side="left", expand=True)
            
            ctk.CTkButton(
                actions_frame,
                text="Edit",
                width=60,
                height=25,
                font=("Helvetica", 12),
                command=lambda: self.edit_transaction(transaction['id'])
            ).pack(side="left", padx=5)
            
            ctk.CTkButton(
                actions_frame,
                text="Delete",
                width=60,
                height=25,
                fg_color="#FF5252",
                hover_color="#FF1744",
                font=("Helvetica", 12),
                command=lambda: self.delete_transaction(transaction['id'])
            ).pack(side="left", padx=5)


    def delete_transaction(self, transaction_id):
        if messagebox.askyesno("Delete Transaction", "Are you sure you want to delete this transaction?"):
            self.cursor.execute("""
                DELETE FROM transactions 
                WHERE id = ? AND user_id = ?
            """, (transaction_id, self.current_user_id))
            self.conn.commit()
            messagebox.showinfo("Success", "Transaction deleted successfully!")
            self.cursor.execute("SELECT type FROM transactions WHERE id = ?", (transaction_id,))
            transaction_type = self.cursor.fetchone()
            if transaction_type == 'income':
                    self.show_income()
            else:
                    self.show_expense()

    def edit_transaction(self, transaction_id):
        self.cursor.execute("""
            SELECT date, category, amount, description, type
            FROM transactions 
            WHERE id = ? AND user_id = ?
        """, (transaction_id, self.current_user_id))
        transaction = self.cursor.fetchone()
        
        if not transaction:
            messagebox.showerror("Error", "Transaction not found!")
            return

        transaction_type = transaction[4]

        form_window = ctk.CTkToplevel(self.root)
        form_window.title(f"Edit {transaction_type.title()}")
        form_window.geometry("400x500")
        form_window.transient(self.root)
        form_window.grab_set()
        form_window.focus_force()

        ctk.CTkLabel(
            form_window,
            text=f"Edit {transaction_type.title()}",
            font=("Helvetica", 20, "bold")
        ).pack(pady=(20, 30))

        form_frame = ctk.CTkFrame(form_window, fg_color="transparent")
        form_frame.pack(fill="both", expand=True, padx=20)
 
        if transaction_type == 'income':
            categories = ["Salary", "Freelance", "Investments", "Business", "Rent", "Other"]
        else:
            categories = ["Food", "Transport", "Bill", "Entertainment", "Rent", "Other"]
        
        date_label = ctk.CTkLabel(form_frame, text="Date:", anchor="w")
        date_label.pack(fill="x", pady=(0, 5))
        date_entry = ctk.CTkEntry(form_frame, placeholder_text="DD-MM-YYYY")
        date_entry.pack(fill="x", pady=(0, 15))
        date_entry.insert(0, transaction[0])

        category_label = ctk.CTkLabel(form_frame, text="Category:", anchor="w")
        category_label.pack(fill="x", pady=(0, 5))
        category_dropdown = ctk.CTkOptionMenu(form_frame, values=categories)
        category_dropdown.pack(fill="x", pady=(0, 15))
        category_dropdown.set(transaction[1])

        def validate_amount(entry_value, char):
            if not (char.isdigit() or char == "."):
                return False
            parts = entry_value.split(".")
            if len(parts[0]) >= 7 and char.isdigit():
                return False

            return True

        validate_cmd = form_window.register(lambda P, S: validate_amount(P, S))
        amount_label = ctk.CTkLabel(form_frame, text="Amount:", anchor="w")
        amount_label.pack(fill="x", pady=(0, 5))
        amount_entry = ctk.CTkEntry(form_frame, placeholder_text="Enter amount",
                            validate="key", validatecommand=(validate_cmd, "%P", "%S"))
        amount_entry.pack(fill="x", pady=(0, 15))

        description_label = ctk.CTkLabel(form_frame, text="Description:", anchor="w")
        description_label.pack(fill="x", pady=(0, 5))
        description_entry = ctk.CTkEntry(form_frame, placeholder_text="Enter description")
        description_entry.pack(fill="x", pady=(0, 15))
        description_entry.insert(0, transaction[3])

        def save_changes():
            try:
                if not date_entry.get() or not amount_entry.get() or not description_entry.get():
                    raise ValueError("Please fill in all fields")
                
                self.cursor.execute("""
                    SELECT amount 
                    FROM transactions 
                    WHERE id = ? AND user_id = ?
                """, (transaction_id, self.current_user_id))
                old_amount = self.cursor.fetchone()[0]  

                self.cursor.execute("""
                    SELECT COALESCE(SUM(amount), 0) 
                    FROM transactions 
                    WHERE type = 'income' AND user_id = ? 
                """, (self.current_user_id,))
                income = self.cursor.fetchone()[0]

                self.cursor.execute("""
                    SELECT COALESCE(SUM(amount), 0) 
                    FROM transactions 
                    WHERE type = 'expense' AND user_id = ?
                """, (self.current_user_id,))
                expense = self.cursor.fetchone()[0]

                balance = income - expense + old_amount
                
                amount = float(amount_entry.get())
                if amount <= 0:
                    raise ValueError("Amount must be greater than zero")
                if amount > 1000000:
                    raise ValueError("The amount exceeds the maximum allowed limit of 1,000,000.")
                if amount > balance and transaction_type == 'expense':
                    raise ValueError(f"You do not have enough money to make this transaction.\n Your balance is {balance}, but the requested amount is {amount}.")
                    
                category = category_dropdown.get()
                description = description_entry.get()
                date = date_entry.get()

                try:
                    datetime.strptime(date, "%d-%m-%Y")
                except ValueError:
                    raise ValueError("Invalid date format. Please use DD-MM-YYYY")
                
                self.cursor.execute("""
                    UPDATE transactions 
                    SET date = ?, category = ?, amount = ?, description = ?
                    WHERE id = ? AND user_id = ?
                """, (date, category, amount, description, transaction_id, self.current_user_id))
                
                self.conn.commit()
                messagebox.showinfo("Success", "Transaction updated successfully!")
                form_window.destroy()

                if transaction_type == 'income':
                    self.show_income()
                else:
                    self.show_expense()
            except ValueError as ve:
                messagebox.showerror("Error", str(ve))
            except Exception as e:
                messagebox.showerror("Error", f"An error occurred: {str(e)}")

        button_frame = ctk.CTkFrame(form_window, fg_color="transparent")
        button_frame.pack(fill="x", padx=20, pady=20)

        ctk.CTkButton(
            button_frame,
            text="Cancel",
            width=100,
            fg_color="#e0e0e0",
            text_color="#2d2d2d",
            hover_color="#c0c0c0",
            command=form_window.destroy
        ).pack(side="left", padx=5)

        ctk.CTkButton(
            button_frame,
            text="Save",
            width=100,
            command=save_changes
        ).pack(side="right", padx=5)

    def export_to_csv(self):
        try:
            self.cursor.execute("SELECT type, category, amount, description, date FROM transactions WHERE user_id = ?", (self.current_user_id,))
            transactions = self.cursor.fetchall()
            
            self.cursor.execute("""
                SELECT 
                    COALESCE(SUM(CASE WHEN type = 'income' THEN amount ELSE 0 END), 0) as total_income,
                    COALESCE(SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END), 0) as total_expense
                FROM transactions 
                WHERE user_id = ?
            """, (self.current_user_id,))
            total_income, total_expense = self.cursor.fetchone()
            total_balance = total_income - total_expense
            
            file_path = filedialog.asksaveasfilename(
                defaultextension="transaction.csv",
                filetypes=[("CSV Files", "*.csv"), ("All Files", "*.*")],
                title="Save Transactions as CSV"
            )
            
            if not file_path:
                return  
            
            with open(file_path, 'w', newline='') as file:
                writer = csv.writer(file)
                
                writer.writerow(["Total Income", "Total Expense", "Total Balance"])
                writer.writerow([total_income, total_expense, total_balance])
                
                writer.writerow([])
                
                writer.writerow(['Type', 'Category', 'Amount', 'Description', 'Date'])
                
                writer.writerows(transactions)
            
            messagebox.showinfo("Success", f"Transactions exported to {file_path}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to export transactions: {str(e)}")

    def search_transactions(self, search_query, transaction_type):
        self.clear_content()

        header = ctk.CTkFrame(self.content, fg_color="transparent")
        header.pack(fill="x", pady=(0, 20))

        ctk.CTkLabel(
            header,
            text=f"Search Results ({transaction_type.title()})",
            font=("Helvetica", 24, "bold"),
            text_color="#2d2d2d"
        ).pack(side="left")

        transactions_frame = ctk.CTkFrame(self.content, fg_color="#f8f9fa", corner_radius=10)
        transactions_frame.pack(fill="both", expand=True, pady=20)

        self.cursor.execute("""
            SELECT id, date, category, description, amount 
            FROM transactions 
            WHERE user_id = ? AND type = ? 
            AND (amount = ? OR date LIKE ? OR category LIKE ? OR description LIKE ?)
            ORDER BY id ASC
        """, (self.current_user_id, transaction_type, search_query, f"%{search_query}%", f"%{search_query}%", f"%{search_query}%"))


        search_results = [
            {
                'id': row[0], 'date': row[1], 'category': row[2],
                'description': row[3], 'amount': row[4], 'type': transaction_type
            }
            for row in self.cursor.fetchall()
        ]

        if not search_results:
            ctk.CTkLabel(
                transactions_frame,
                text="No matching transactions found.",
                font=("Helvetica", 12),
                text_color="#666666"
            ).pack(pady=20)
        else:
            headers = ctk.CTkFrame(transactions_frame, fg_color="transparent")
            headers.pack(fill="x", padx=20, pady=5)
            
            header_titles = ["Date", "Category", "Description", "Amount"]
            for title in header_titles:
                ctk.CTkLabel(
                    headers,
                    text=title,
                    font=("Helvetica", 12, "bold"),
                    text_color="#666666"
                ).pack(side="left", expand=True)

            for transaction in search_results:
                self.create_transaction_row(transactions_frame, transaction, show_type=False)

    def show_dashboard(self):
        self.clear_content()
        header = ctk.CTkFrame(self.content, fg_color="transparent")
        header.pack(fill="x", pady=(0, 20))
        
        ctk.CTkLabel(
            header,
            text="Dashboard",
            font=("Helvetica", 24, "bold"),
            text_color="#2d2d2d"
        ).pack(side="left")
        
        ctk.CTkLabel(
            header,
            text=datetime.now().strftime("%B %d, %Y"),
            font=("Helvetica", 14),
            text_color="#666666"
        ).pack(side="right")

        summary = self.get_transactions_summary()
        
        cards = ctk.CTkFrame(self.content, fg_color="transparent")
        cards.pack(fill="x", pady=10)
        
        summary_data = [
            ("Total Balance", self.format_amount(summary['total_balance']), "#e8f5e9"),
            ("Total Income", self.format_amount(summary['total_income']), "#e3f2fd"),
            ("Total Expenses", self.format_amount(summary['total_expense']), "#fbe9e7")
        ]
        
        for title, amount, color in summary_data:
            card = ctk.CTkFrame(cards, fg_color=color, corner_radius=10)
            card.pack(side="left", expand=True, padx=10, fill="both")
            
            ctk.CTkLabel(
                card,
                text=title,
                font=("Helvetica", 14),
                text_color="#666666"
            ).pack(pady=(15, 5), padx=15)
            
            ctk.CTkLabel(
                card,
                text=amount,
                font=("Helvetica", 24, "bold"),
                text_color="#2d2d2d"
            ).pack(pady=(0, 15), padx=15)

        transactions = ctk.CTkFrame(self.content, fg_color="#f8f9fa", corner_radius=10)
        transactions.pack(fill="both", expand=True, pady=20)
        
        ctk.CTkLabel(
            transactions,
            text="Recent Transactions",
            font=("Helvetica", 18, "bold"),
            text_color="#2d2d2d"
        ).pack(pady=15, padx=20, anchor="w")

        headers = ctk.CTkFrame(transactions, fg_color="transparent")
        headers.pack(fill="x", padx=20)
        
        header_titles = ["Date", "Category", "Type", "Description", "Amount"]
        for title in header_titles:
            ctk.CTkLabel(
                headers,
                text=title,
                font=("Helvetica", 12, "bold"),
                text_color="#666666"
            ).pack(side="left", expand=True)

        self.cursor.execute("""
            SELECT id, date, category, type, description, amount 
            FROM transactions 
            WHERE user_id = ?
            ORDER BY id DESC 
            LIMIT 10
        """, (self.current_user_id,))
        recent_transactions = [
            {
                'id': row[0], 'date': row[1], 'category': row[2],
                'type': row[3], 'description': row[4], 'amount': row[5]
            }
            for row in self.cursor.fetchall()
        ]

        for transaction in recent_transactions:
            self.create_transaction_row(transactions, transaction)

    def show_income(self):
        self.clear_content()
        
        header = ctk.CTkFrame(self.content, fg_color="transparent")
        header.pack(fill="x", pady=(0, 20), padx=20)

        ctk.CTkLabel(
            header,
            text="Income",
            font=("Helvetica", 24, "bold"),
            text_color="#2d2d2d"
        ).pack(side="left")

        ctk.CTkButton(
            header,
            text="+ Add Income",
            font=("Helvetica", 14),
            width=120,
            height=40,
            corner_radius=20,
            command=self.show_add_income_form
        ).pack(side="right")

        summary_frame = ctk.CTkFrame(self.content, fg_color="#f8f9fa", corner_radius=10)
        summary_frame.pack(fill="x", padx=20, pady=10)

        total_income_label = ctk.CTkLabel(
            summary_frame,
            text="Total Income:",
            font=("Helvetica", 16, "bold"),
            text_color="#2d2d2d"
        )
        total_income_label.pack(side="left", padx=10, pady=10)

        self.cursor.execute("""
            SELECT COALESCE(SUM(amount), 0) 
            FROM transactions 
            WHERE type = 'income' AND user_id = ?
        """, (self.current_user_id,))
        total_income = self.cursor.fetchone()[0]

        total_income_value = ctk.CTkLabel(
            summary_frame,
            text=self.format_amount(total_income),
            font=("Helvetica", 16, "bold"),
            text_color="#4CAF50"
        )
        total_income_value.pack(side="left", padx=10, pady=10)

        search_frame = ctk.CTkFrame(summary_frame, fg_color="transparent")
        search_frame.pack(side="right", padx=10, pady=10)

        search_entry = ctk.CTkEntry(search_frame, placeholder_text="Search Income", width=200)
        search_entry.pack(side="left", padx=5)

        def on_search():
            query = search_entry.get()
            if query:
                self.search_transactions(query, "income")

        search_button = ctk.CTkButton(search_frame, text="Search", command=on_search, width=80)
        search_button.pack(side="left")

        transactions_frame = ctk.CTkFrame(self.content, fg_color="transparent")
        transactions_frame.pack(fill="x", padx=20, pady=10)

        headers = ["Date", "Category", "Description", "Amount", "Actions"]
        for title in headers:
            ctk.CTkLabel(
                transactions_frame,
                text=title,
                font=("Helvetica", 12, "bold"),
                text_color="#666666"
            ).pack(side="left", expand=True)

        transactions_container = ctk.CTkScrollableFrame(self.content, fg_color="transparent")
        transactions_container.pack(fill="both", expand=True, padx=20, pady=10)

        try:
            self.cursor.execute("""
                SELECT id, date, category, description, amount 
                FROM transactions 
                WHERE type = 'income' AND user_id = ?
                ORDER BY 
                    date DESC,
                    id DESC
            """, (self.current_user_id,))
            
            income_transactions = [
                {
                    'id': row[0],
                    'date': row[1],
                    'category': row[2],
                    'description': row[3],
                    'amount': row[4],
                    'type': 'income'
                }
                for row in self.cursor.fetchall()
            ]

            if not income_transactions:
                ctk.CTkLabel(
                    transactions_container,
                    text="No income transactions found",
                    font=("Helvetica", 12),
                    text_color="#666666"
                ).pack(pady=20)
            else:
                for transaction in income_transactions:
                    self.create_transaction_row(transactions_container, transaction, show_type=False)

        except Exception as e:
            messagebox.showerror("Error", f"Failed to load income transactions: {str(e)}")

    def show_add_income_form(self):
        form_window = ctk.CTkToplevel(self.root)
        form_window.title("Add Income")
        form_window.geometry("400x500")
        form_window.transient(self.root)
        form_window.grab_set()
        form_window.focus_force()

        ctk.CTkLabel(
            form_window,
            text="Add New Income",
            font=("Helvetica", 20, "bold")
        ).pack(pady=(20, 30))

        form_frame = ctk.CTkFrame(form_window, fg_color="transparent")
        form_frame.pack(fill="both", expand=True, padx=20)

        categories = ["Salary", "Freelance", "Investments", "Business", "Rent", "Other"]

        date_label = ctk.CTkLabel(form_frame, text="Date:", font=("Helvetica", 14,), anchor="w")
        date_label.pack(fill="x", pady=(0, 5))

        date_entry_frame = ctk.CTkFrame(form_frame, fg_color="transparent", border_width=2, corner_radius=5)
        date_entry_frame.pack(fill="x", pady=(0, 15))

        date_entry = DateEntry(
            date_entry_frame, 
            width=22, 
            font=("Helvetica", 14), 
            background="#2D2D2D", 
            foreground="white", 
            borderwidth=0, 
            date_pattern="dd-mm-yyyy"
        )
        date_entry.pack(fill="x", padx=10, pady=8)  

        category_label = ctk.CTkLabel(form_frame, text="Category:", anchor="w")
        category_label.pack(fill="x", pady=(0, 5))
        category_dropdown = ctk.CTkOptionMenu(form_frame, values=categories)
        category_dropdown.pack(fill="x", pady=(0, 15))

        def validate_amount(entry_value, char):
            if not (char.isdigit() or char == "."):
                return False
            parts = entry_value.split(".")
            if len(parts[0]) >= 7 and char.isdigit():
                return False

            return True

        validate_cmd = form_window.register(lambda P, S: validate_amount(P, S))
        amount_label = ctk.CTkLabel(form_frame, text="Amount:", anchor="w")
        amount_label.pack(fill="x", pady=(0, 5))
        amount_entry = ctk.CTkEntry(form_frame, placeholder_text="Enter amount",
                            validate="key", validatecommand=(validate_cmd, "%P", "%S"))
        amount_entry.pack(fill="x", pady=(0, 15))

        description_label = ctk.CTkLabel(form_frame, text="Description:", anchor="w")
        description_label.pack(fill="x", pady=(0, 5))
        description_entry = ctk.CTkEntry(form_frame, placeholder_text="Enter description")
        description_entry.pack(fill="x", pady=(0, 15))

        def save_income():
            try:
                if not self.current_user_id:
                    raise ValueError("User not logged in")

                if not amount_entry.get() or not description_entry.get():
                    raise ValueError("Please fill in all fields")

                amount = float(amount_entry.get())
                if amount <= 0:
                    raise ValueError("Amount must be greater than zero")
                if amount > 1000000:
                    raise ValueError("The amount exceeds the maximum allowed limit of 1,000,000.")

                category = category_dropdown.get()
                description = description_entry.get()
                date = date_entry.get_date().strftime("%d-%m-%Y")  # Get date from calendar widget

                self.cursor.execute("""
                    INSERT INTO transactions (user_id, type, category, amount, description, date)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (self.current_user_id, "income", category, amount, description, date))

                self.conn.commit()
                messagebox.showinfo("Success", "Income added successfully!")
                form_window.destroy()
                self.show_income()
            except ValueError as ve:
                messagebox.showerror("Error", str(ve))
            except Exception as e:
                messagebox.showerror("Error", f"An error occurred: {str(e)}")

        button_frame = ctk.CTkFrame(form_window, fg_color="transparent")
        button_frame.pack(fill="x", padx=20, pady=20)

        ctk.CTkButton(
            button_frame,
            text="Cancel",
            width=100,
            fg_color="#e0e0e0",
            text_color="#2d2d2d",
            hover_color="#c0c0c0",
            command=form_window.destroy
        ).pack(side="left", padx=5)

        ctk.CTkButton(
            button_frame,
            text="Save",
            width=100,
            command=save_income
        ).pack(side="right", padx=5)

    def show_expense(self):
        self.clear_content()

        header = ctk.CTkFrame(self.content, fg_color="transparent")
        header.pack(fill="x", pady=(0, 20), padx=20)

        ctk.CTkLabel(
            header,
            text="Expense",
            font=("Helvetica", 24, "bold"),
            text_color="#2d2d2d"
        ).pack(side="left")

        ctk.CTkButton(
            header,
            text="+ Add Expense",
            font=("Helvetica", 14),
            width=120,
            height=40,
            corner_radius=20,
            command=self.show_add_Expense_form
        ).pack(side="right")

        summary_frame = ctk.CTkFrame(self.content, fg_color="#f8f9fa", corner_radius=10)
        summary_frame.pack(fill="x", padx=20, pady=10)

        total_expense_label = ctk.CTkLabel(
            summary_frame,
            text="Total Expense:",
            font=("Helvetica", 16, "bold"),
            text_color="#2d2d2d"
        )
        total_expense_label.pack(side="left", padx=10, pady=10)

        self.cursor.execute("""
            SELECT COALESCE(SUM(amount), 0) 
            FROM transactions 
            WHERE type = 'expense' AND user_id = ?
        """, (self.current_user_id,))
        total_expense = self.cursor.fetchone()[0]

        total_expense_value = ctk.CTkLabel(
            summary_frame,
            text=self.format_amount(total_expense),
            font=("Helvetica", 16, "bold"),
            text_color="#F44336"
        )
        total_expense_value.pack(side="left", padx=10, pady=10)

        search_frame = ctk.CTkFrame(summary_frame, fg_color="transparent")
        search_frame.pack(side="right", padx=10, pady=10)

        search_entry = ctk.CTkEntry(search_frame, placeholder_text="Search Expense", width=200)
        search_entry.pack(side="left", padx=5)

        def on_search():
            query = search_entry.get()
            if query:
                self.search_transactions(query, "expense")

        search_button = ctk.CTkButton(search_frame, text="Search", command=on_search, width=80)
        search_button.pack(side="left")

        transactions_frame = ctk.CTkFrame(self.content, fg_color="transparent")
        transactions_frame.pack(fill="x", padx=20, pady=10)

        headers = ["Date", "Category", "Description", "Amount", "Actions"]
        for title in headers:
            ctk.CTkLabel(
                transactions_frame,
                text=title,
                font=("Helvetica", 12, "bold"),
                text_color="#666666"
            ).pack(side="left", expand=True)

        transactions_container = ctk.CTkScrollableFrame(self.content, fg_color="transparent")
        transactions_container.pack(fill="both", expand=True, padx=20, pady=10)

        try:
            self.cursor.execute("""
                SELECT id, date, category, description, amount 
                FROM transactions 
                WHERE type = 'expense' AND user_id = ?
                ORDER BY date DESC,
                                id DESC
            """, (self.current_user_id,))

            expense_transactions = [
                {
                    'id': row[0],
                    'date': row[1],
                    'category': row[2],
                    'description': row[3],
                    'amount': row[4],
                    'type': 'expense'
                }
                for row in self.cursor.fetchall()
            ]

            if not expense_transactions:
                ctk.CTkLabel(
                    transactions_container,
                    text="No expense transactions found",
                    font=("Helvetica", 12),
                    text_color="#666666"
                ).pack(pady=20)
            else:
                for transaction in expense_transactions:
                    self.create_transaction_row(transactions_container, transaction, show_type=False)

        except Exception as e:
            messagebox.showerror("Error", f"Failed to load expense transactions: {str(e)}")


    def show_add_Expense_form(self):
        form_window = ctk.CTkToplevel(self.root)
        form_window.title("Add Expense")
        form_window.geometry("400x500")
        form_window.transient(self.root)
        form_window.grab_set()

        form_window.focus_force()
        
        ctk.CTkLabel(
            form_window,
            text="Add New Expense",
            font=("Helvetica", 20, "bold")
        ).pack(pady=(20, 30))

        form_frame = ctk.CTkFrame(form_window, fg_color="transparent")
        form_frame.pack(fill="both", expand=True, padx=20)
        
        categories = ["Food", "Transport", "Bill", "Entertainment", "Rent", "Other"]
        
        date_label = ctk.CTkLabel(form_frame, text="Date:", font=("Helvetica", 14,), anchor="w")
        date_label.pack(fill="x", pady=(0, 5))

        date_entry_frame = ctk.CTkFrame(form_frame, fg_color="transparent", border_width=2, corner_radius=5)
        date_entry_frame.pack(fill="x", pady=(0, 15))

        date_entry = DateEntry(
            date_entry_frame, 
            width=22, 
            font=("Helvetica", 14), 
            background="#2D2D2D", 
            foreground="white", 
            borderwidth=0, 
            date_pattern="dd-mm-yyyy"
        )
        date_entry.pack(fill="x", padx=10, pady=8)
        
        category_label = ctk.CTkLabel(form_frame, text="Category:", anchor="w")
        category_label.pack(fill="x", pady=(0, 5))
        category_dropdown = ctk.CTkOptionMenu(form_frame, values=categories)
        category_dropdown.pack(fill="x", pady=(0, 15))
        
        def validate_amount(entry_value, char):
            if not (char.isdigit() or char == "."):
                return False
            parts = entry_value.split(".")
            if len(parts[0]) >= 7 and char.isdigit():
                return False

            return True

        validate_cmd = form_window.register(lambda P, S: validate_amount(P, S))
        amount_label = ctk.CTkLabel(form_frame, text="Amount:", anchor="w")
        amount_label.pack(fill="x", pady=(0, 5))
        amount_entry = ctk.CTkEntry(form_frame, placeholder_text="Enter amount",
                            validate="key", validatecommand=(validate_cmd, "%P", "%S"))
        amount_entry.pack(fill="x", pady=(0, 15))
        
        description_label = ctk.CTkLabel(form_frame, text="Description:", anchor="w")
        description_label.pack(fill="x", pady=(0, 5))
        description_entry = ctk.CTkEntry(form_frame, placeholder_text="Enter description")
        description_entry.pack(fill="x", pady=(0, 15))
        
        def save_expense():  
            try:
                if not self.current_user_id:  
                    raise ValueError("User not logged in")

                if not date_entry.get() or not amount_entry.get() or not description_entry.get():
                    raise ValueError("Please fill in all fields")

                amount = float(amount_entry.get())
                if amount <= 0:
                    raise ValueError("Amount must be greater than zero")
                if amount > 1000000:
                    raise ValueError("The amount exceeds the maximum allowed limit of 1,000,000.")

                self.cursor.execute("""
                    SELECT COALESCE(SUM(CASE WHEN type = 'income' THEN amount ELSE -amount END), 0)
                    FROM transactions 
                    WHERE user_id = ?
                """, (self.current_user_id,))
                balance = self.cursor.fetchone()[0]

                if amount > balance:
                    raise ValueError(f"You do not have enough money to make this transaction.\n Your balance is {balance}, but the requested amount is {amount}.")

                date = date_entry.get()
                description = description_entry.get()

                try:
                    datetime.strptime(date, "%d-%m-%Y")
                except ValueError:
                    raise ValueError("Invalid date format. Please use DD-MM-YYYY")
                
                category = category_dropdown.get()
                
                self.cursor.execute("""
                    SELECT id, budgeted_amount 
                    FROM budgets 
                    WHERE category = ? AND user_id = ?
                """, (category, self.current_user_id))
                budget = self.cursor.fetchone()

                if not budget:
                    response = messagebox.askyesno(
                        "No Budget Found",
                        f"No budget exists for the category '{category}'. Would you like to create one?"
                    )
                    if response:
                        self.show_add_budget_form()
                        return  
                    else:
                        pass
                else:
                    budget_id, budgeted_amount = budget

                    self.cursor.execute("""
                        SELECT COALESCE(SUM(amount), 0) 
                        FROM transactions 
                        WHERE type = 'expense' AND category = ? AND user_id = ?
                    """, (category, self.current_user_id))
                    current_spending = self.cursor.fetchone()[0]

                    if current_spending + amount > budgeted_amount:
                        response = messagebox.askquestion(
                            "Budget Limit Exceeded",
                            f"This expense will exceed your budget for '{category}':\n\n" +
                            f"Budget: Rs. {budgeted_amount:,.2f}\n" +
                            f"Current Spending: Rs. {current_spending:,.2f}\n" +
                            f"New Expense: Rs. {amount:,.2f}\n" +
                            f"Exceeds by: Rs. {(current_spending + amount - budgeted_amount):,.2f}\n\n" +
                            "Would you like to edit the budget?",
                            icon='warning',
                            type='yesnocancel'
                        )
                        
                        if response == 'yes':
                            self.edit_budget(budget_id)
                            return 
                        elif response == 'cancel':
                            return
  
                self.cursor.execute("""
                    INSERT INTO transactions (user_id, type, category, amount, description, date)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (self.current_user_id, "expense", category, amount, description, date))

                self.conn.commit()
                messagebox.showinfo("Success", "Expense added successfully!")
                form_window.destroy()
                self.show_expense()

            except ValueError as ve:
                messagebox.showerror("Error", str(ve))
            except Exception as e:
                messagebox.showerror("Error", f"An error occurred: {str(e)}")
        
        button_frame = ctk.CTkFrame(form_window, fg_color="transparent")
        button_frame.pack(fill="x", padx=20, pady=20)
        
        ctk.CTkButton(
            button_frame,
            text="Cancel",
            width=100,
            fg_color="#e0e0e0",
            text_color="#2d2d2d",
            hover_color="#c0c0c0",
            command=form_window.destroy
        ).pack(side="left", padx=5)
        
        ctk.CTkButton(
            button_frame,
            text="Save",
            width=100,
            command=save_expense
        ).pack(side="right", padx=5)

    def show_budget(self):
        self.clear_content()

        header = ctk.CTkFrame(self.content, fg_color="transparent")
        header.pack(fill="x", pady=(0, 20))
        
        ctk.CTkLabel(
            header,
            text="Budget Management",
            font=("Helvetica", 24, "bold"),
            text_color="#2d2d2d"
        ).pack(side="left")

        ctk.CTkButton(
            header,
            text="+ Add Budget",
            font=("Helvetica", 14),
            width=120,
            height=40,
            corner_radius=20,
            command=self.show_add_budget_form
        ).pack(side="right")

        budget_frame = ctk.CTkFrame(self.content, fg_color="#f8f9fa", corner_radius=10)
        budget_frame.pack(fill="both", expand=True, pady=20)

        headers = ctk.CTkFrame(budget_frame, fg_color="transparent")
        headers.pack(fill="x", padx=20, pady=15)
        
        header_titles = ["Category", "Budgeted Amount", "Spent Amount", "Remaining", "Status"]
        for title in header_titles:
            ctk.CTkLabel(
                headers,
                text=title,
                font=("Helvetica", 12, "bold"),
                text_color="#666666"
            ).pack(side="left", expand=True)

        budgets_container = ctk.CTkScrollableFrame(budget_frame, fg_color="transparent")
        budgets_container.pack(fill="both", expand=True, padx=20, pady=(0, 20))

        self.display_existing_budgets(budgets_container)

    def display_existing_budgets(self, container):
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS budgets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                category TEXT NOT NULL,
                budgeted_amount REAL NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        """)
        self.conn.commit()

        self.cursor.execute("""
            SELECT b.id, b.category, b.budgeted_amount, 
                COALESCE(SUM(t.amount), 0) as spent_amount
            FROM budgets b
            LEFT JOIN transactions t ON b.category = t.category AND t.type = 'expense' AND t.user_id = b.user_id
            WHERE b.user_id = ?
            GROUP BY b.id, b.category, b.budgeted_amount
        """, (self.current_user_id,))
        
        budgets = self.cursor.fetchall()

        if not budgets:
            ctk.CTkLabel(
                container,
                text="No budgets set. Add a budget to get started!",
                font=("Helvetica", 12),
                text_color="#666666"
            ).pack(pady=20)
            return

        for budget in budgets:
            budget_id, category, budgeted_amount, spent_amount = budget
            remaining = budgeted_amount - spent_amount
            status_color = "#4CAF50"  # Green (within budget)
            if spent_amount > budgeted_amount:
                status_color = "#F44336"  # Red (over budget)
            elif spent_amount / budgeted_amount > 0.8:
                status_color = "#FFC107"  # Yellow (approaching budget limit)

            row = ctk.CTkFrame(container, fg_color="transparent")
            row.pack(fill="x", padx=20, pady=5)

            ctk.CTkLabel(
                row,
                text=category,
                font=("Helvetica", 12),
                text_color="#2d2d2d"
            ).pack(side="left", expand=True)

            ctk.CTkLabel(
                row,
                text=f"Rs. {budgeted_amount:,.2f}",
                font=("Helvetica", 12),
                text_color="#2d2d2d"
            ).pack(side="left", expand=True)

            ctk.CTkLabel(
                row,
                text=f"Rs. {spent_amount:,.2f}",
                font=("Helvetica", 12),
                text_color="#F44336"
            ).pack(side="left", expand=True)

            ctk.CTkLabel(
                row,
                text=f"Rs. {remaining:,.2f}",
                font=("Helvetica", 12),
                text_color="#2d2d2d"
            ).pack(side="left", expand=True)

            status_label = ctk.CTkLabel(
                row,
                text="●",
                font=("Helvetica", 20, "bold"),
                text_color=status_color
            )
            status_label.pack(side="left", expand=True)

            actions_frame = ctk.CTkFrame(row, fg_color="transparent")
            actions_frame.pack(side="left", expand=True)
            
            ctk.CTkButton(
                actions_frame,
                text="Edit",
                width=60,
                height=25,
                font=("Helvetica", 12),
                command=lambda bid=budget_id: self.edit_budget(bid)
            ).pack(side="left", padx=5)
            
            ctk.CTkButton(
                actions_frame,
                text="Delete",
                width=60,
                height=25,
                fg_color="#FF5252",
                hover_color="#FF1744",
                font=("Helvetica", 12),
                command=lambda bid=budget_id: self.delete_budget(bid)
            ).pack(side="left", padx=5)

    def show_add_budget_form(self):
        form_window = ctk.CTkToplevel(self.root)
        form_window.title("Add Budget")
        form_window.geometry("400x500")
        form_window.transient(self.root)
        form_window.grab_set()
        form_window.focus_force()
        
        ctk.CTkLabel(
            form_window,
            text="Add New Budget",
            font=("Helvetica", 20, "bold")
        ).pack(pady=(20, 30))

        form_frame = ctk.CTkFrame(form_window, fg_color="transparent")
        form_frame.pack(fill="both", expand=True, padx=20)

        categories = ["Food", "Transport", "Bill", "Entertainment", "Rent", "Other"]
        
        category_label = ctk.CTkLabel(form_frame, text="Category:", anchor="w")
        category_label.pack(fill="x", pady=(0, 5))
        category_dropdown = ctk.CTkOptionMenu(form_frame, values=categories)
        category_dropdown.pack(fill="x", pady=(0, 15))
        
        def validate_amount(entry_value, char):
            if not (char.isdigit() or char == "."):
                return False
            parts = entry_value.split(".")
            if len(parts[0]) >= 7 and char.isdigit():
                return False

            return True

        validate_cmd = form_window.register(lambda P, S: validate_amount(P, S))
        amount_label = ctk.CTkLabel(form_frame, text="Amount:", anchor="w")
        amount_label.pack(fill="x", pady=(0, 5))
        amount_entry = ctk.CTkEntry(form_frame, placeholder_text="Enter amount",
                            validate="key", validatecommand=(validate_cmd, "%P", "%S"))
        amount_entry.pack(fill="x", pady=(0, 15))
        
        def save_budget():
            try:
                amount = float(amount_entry.get())
                if amount <= 0:
                    raise ValueError("Amount must be greater than zero")
                if amount > 1000000:
                    raise ValueError("The amount exceeds the maximum allowed limit of 1,000,000.")
                
                category = category_dropdown.get()
                
                self.cursor.execute("""
                    SELECT COUNT(*) FROM budgets 
                    WHERE user_id = ? AND category = ?
                """, (self.current_user_id, category))
                
                if self.cursor.fetchone()[0] > 0:
                    if not messagebox.askyesno("Budget Exists", 
                        "A budget for this category already exists. Do you want to update it?"):
                        return
                    
                    self.cursor.execute("""
                        UPDATE budgets 
                        SET budgeted_amount = ? 
                        WHERE user_id = ? AND category = ?
                    """, (amount, self.current_user_id, category))
                else:
                    self.cursor.execute("""
                        INSERT INTO budgets (user_id, category, budgeted_amount) 
                        VALUES (?, ?, ?)
                    """, (self.current_user_id, category, amount))
                
                self.conn.commit()
                messagebox.showinfo("Success", "Budget added/updated successfully!")
                form_window.destroy()
                self.show_budget()
            
            except ValueError as ve:
                messagebox.showerror("Error", str(ve))
            except Exception as e:
                messagebox.showerror("Error", f"An error occurred: {str(e)}")
        
        button_frame = ctk.CTkFrame(form_window, fg_color="transparent")
        button_frame.pack(fill="x", padx=20, pady=20)
        
        ctk.CTkButton(
            button_frame,
            text="Cancel",
            width=100,
            fg_color="#e0e0e0",
            text_color="#2d2d2d",
            hover_color="#c0c0c0",
            command=form_window.destroy
        ).pack(side="left", padx=5)
        
        ctk.CTkButton(
            button_frame,
            text="Save",
            width=100,
            command=save_budget
        ).pack(side="right", padx=5)

    def edit_budget(self, budget_id):
        self.cursor.execute("""
            SELECT category, budgeted_amount 
            FROM budgets 
            WHERE id = ? AND user_id = ?
        """, (budget_id, self.current_user_id))
        budget = self.cursor.fetchone()
        
        if not budget:
            messagebox.showerror("Error", "Budget not found!")
            return
        
        form_window = ctk.CTkToplevel(self.root)
        form_window.title("Edit Budget")
        form_window.geometry("400x500")
        form_window.transient(self.root)
        form_window.grab_set()
        form_window.focus_force()
        
        ctk.CTkLabel(
            form_window,
            text="Edit Budget",
            font=("Helvetica", 20, "bold")
        ).pack(pady=(20, 30))

        form_frame = ctk.CTkFrame(form_window, fg_color="transparent")
        form_frame.pack(fill="both", expand=True, padx=20)
        
        categories = ["Food", "Transport", "Bill", "Entertainment", "Rent", "Other"]
        
        category_label = ctk.CTkLabel(form_frame, text="Category:", anchor="w")
        category_label.pack(fill="x", pady=(0, 5))
        category_dropdown = ctk.CTkOptionMenu(form_frame, values=categories)
        category_dropdown.pack(fill="x", pady=(0, 15))
        category_dropdown.set(budget[0])
        
        def validate_amount(entry_value, char):
            if not (char.isdigit() or char == "."):
                return False
            parts = entry_value.split(".")
            if len(parts[0]) >= 7 and char.isdigit():
                return False

            return True

        validate_cmd = form_window.register(lambda P, S: validate_amount(P, S))
        amount_label = ctk.CTkLabel(form_frame, text="Amount:", anchor="w")
        amount_label.pack(fill="x", pady=(0, 5))
        amount_entry = ctk.CTkEntry(form_frame, placeholder_text="Enter amount",
                            validate="key", validatecommand=(validate_cmd, "%P", "%S"))
        amount_entry.pack(fill="x", pady=(0, 15)) 
        
        def update_budget():
            try:
                amount = float(amount_entry.get())
                if amount <= 0:
                    raise ValueError("Amount must be greater than zero")
                if amount > 1000000:
                    raise ValueError("The amount exceeds the maximum allowed limit of 1,000,000.")
                
                category = category_dropdown.get()
                
                self.cursor.execute("""
                    UPDATE budgets 
                    SET category = ?, budgeted_amount = ? 
                    WHERE id = ? AND user_id = ?
                """, (category, amount, budget_id, self.current_user_id))
                
                self.conn.commit()
                messagebox.showinfo("Success", "Budget updated successfully!")
                form_window.destroy()
                self.show_budget()
            
            except ValueError as ve:
                messagebox.showerror("Error", str(ve))
            except Exception as e:
                messagebox.showerror("Error", f"An error occurred: {str(e)}")
        
        button_frame = ctk.CTkFrame(form_window, fg_color="transparent")
        button_frame.pack(fill="x", padx=20, pady=20)
        
        ctk.CTkButton(
            button_frame,
            text="Cancel",
            width=100,
            fg_color="#e0e0e0",
            text_color="#2d2d2d",
            hover_color="#c0c0c0",
            command=form_window.destroy
        ).pack(side="left", padx=5)
        
        ctk.CTkButton(
            button_frame,
            text="Update",
            width=100,
            command=update_budget
        ).pack(side="right", padx=5)

    def delete_budget(self, budget_id):
        if messagebox.askyesno("Delete Budget", "Are you sure you want to delete this budget?"):
            try:
                self.cursor.execute("""
                    DELETE FROM budgets 
                    WHERE id = ? AND user_id = ?
                """, (budget_id, self.current_user_id))
                
                self.conn.commit()
                messagebox.showinfo("Success", "Budget deleted successfully!")
                self.show_budget()
            except Exception as e:
                messagebox.showerror("Error", f"An error occurred: {str(e)}")
    
    def show_edit_profile_form(self):
        form_window = ctk.CTkToplevel(self.root)
        form_window.title("Edit Profile")
        form_window.geometry("400x500")
        form_window.transient(self.root)
        form_window.grab_set()
        form_window.focus_force()
        
        ctk.CTkLabel(
            form_window,
            text="Edit Profile",
            font=("Helvetica", 20, "bold")
        ).pack(pady=(20, 30))

        form_frame = ctk.CTkFrame(form_window, fg_color="transparent")
        form_frame.pack(fill="both", expand=True, padx=20)
        
        self.cursor.execute("SELECT name, email, contact FROM users WHERE id = ?", (self.current_user_id,))
        user = self.cursor.fetchone()
        
        name_label = ctk.CTkLabel(form_frame, text="Name:", anchor="w")
        name_label.pack(fill="x", pady=(0, 5))
        name_entry = ctk.CTkEntry(form_frame, placeholder_text="Full Name")
        name_entry.pack(fill="x", pady=(0, 15))
        name_entry.insert(0, user[0])
        
        email_label = ctk.CTkLabel(form_frame, text="Email:", anchor="w")
        email_label.pack(fill="x", pady=(0, 5))
        email_entry = ctk.CTkEntry(form_frame, placeholder_text="Email Address")
        email_entry.pack(fill="x", pady=(0, 15))
        email_entry.insert(0, user[1])
        
        contact_label = ctk.CTkLabel(form_frame, text="Contact:", anchor="w")
        contact_label.pack(fill="x", pady=(0, 5))
        contact_entry = ctk.CTkEntry(form_frame, placeholder_text="Contact Number")
        contact_entry.pack(fill="x", pady=(0, 15))
        contact_entry.insert(0, user[2])
        
        def save_profile():
            try:
                name = name_entry.get()
                email = email_entry.get()
                contact = contact_entry.get()
                
                if not name:
                    raise ValueError("Please enter your name")
                
                if not email or '@' not in email:
                    raise ValueError("Please enter a valid email address")
                
                if not contact or len(contact) != 10 or not contact.isdigit():
                    raise ValueError("Please enter a valid contact number")
                
                self.cursor.execute("UPDATE users SET name = ?, email = ?, contact = ? WHERE id = ?", (name, email, contact, self.current_user_id))
                self.conn.commit()
                self.username_label.configure(text=name)
                messagebox.showinfo("Success", "Profile updated successfully!")
                form_window.destroy()
            except ValueError as ve:
                messagebox.showerror("Error", str(ve))
            except Exception as e:
                messagebox.showerror("Error", f"An error occurred: {str(e)}")
        
        button_frame = ctk.CTkFrame(form_window, fg_color="transparent")
        button_frame.pack(fill="x", padx=20, pady=20)
        
        ctk.CTkButton(
            button_frame,
            text="Cancel",
            width=100,
            fg_color="#e0e0e0",
            text_color="#2d2d2d",
            hover_color="#c0c0c0",
            command=form_window.destroy
        ).pack(side="left", padx=5)
        
        ctk.CTkButton(
            button_frame,
            text="Save",
            width=100,
            command=save_profile
        ).pack(side="right", padx=5)

    def clear_content(self):
        for widget in self.content.winfo_children():
            widget.destroy()

    def logout(self):
        if messagebox.askyesno("Logout", "Are you sure you want to logout?"):
            self.current_user_id = None
            self.root.destroy()
            try:
                from main import FinTrack
                login = FinTrack()
                login.run()
            except ImportError:
                messagebox.showinfo("Info", "Logged out successfully")

    def run(self):
        self.root.mainloop()

if __name__ == "__main__":
    app = FinTrack()
    app.run()