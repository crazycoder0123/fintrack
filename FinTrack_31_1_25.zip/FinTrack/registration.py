from customtkinter import *
from tkinter import messagebox
from PIL import Image


class ModernRegistrationPage:
    def __init__(self):
        set_appearance_mode("light")
        set_default_color_theme("green")

        self.root = CTk()
        self.root.geometry('500x700+500+50')
        self.root.title('FinTrack')
        self.root.resizable(False, False)

        self.container = CTkFrame(self.root, fg_color="#ffffff")
        self.container.pack(fill="both", expand=True)

        self.show_password = False
        self.create_registration_form()

    def toggle_password_visibility(self):
        self.show_password = not self.show_password
        if self.show_password:
            self.password.configure(show="")
            self.show_pass_button.configure(text="🔒")
        else:
            self.password.configure(show="●")
            self.show_pass_button.configure(text="👁️")

    def create_registration_form(self):

        self.logo = CTkImage(Image.open('img\\logo.png'), size=(120, 120))
        self.logo_label = CTkLabel(self.container, image=self.logo, text='')
        self.logo_label.pack(pady=(50, 20))

        CTkLabel(
            self.container,
            text="Create Account",
            font=("Helvetica", 28, "bold"),
            text_color="#2d2d2d"
        ).pack(pady=(0, 10))

        CTkLabel(
            self.container,
            text="Please fill in your details",
            font=("Helvetica", 14),
            text_color="#666666"
        ).pack(pady=(0, 30))

        self.name = CTkEntry(
            self.container,
            placeholder_text="Full Name",
            width=320,
            height=50,
            font=("Helvetica", 12),
            border_width=2,
            corner_radius=10
        )
        self.name.pack(pady=(0, 20))

        self.email = CTkEntry(
            self.container,
            placeholder_text="Email Address",
            width=320,
            height=50,
            font=("Helvetica", 12),
            border_width=2,
            corner_radius=10
        )
        self.email.pack(pady=(0, 20))

        self.contact = CTkEntry(
            self.container,
            placeholder_text="Contact Number",
            width=320,
            height=50,
            font=("Helvetica", 12),
            border_width=2,
            corner_radius=10
        )
        self.contact.pack(pady=(0, 20))

        self.password_frame = CTkFrame(self.container, fg_color="transparent")
        self.password_frame.pack(pady=(0, 20))

        self.password = CTkEntry(
            self.password_frame,
            placeholder_text="Password",
            width=320,
            height=50,
            font=("Helvetica", 12),
            border_width=2,
            corner_radius=10,
            show="●"
        )
        self.password.pack(side="left")

        self.show_pass_button = CTkButton(
            self.password,
            text="👁️",
            width=20,
            height=20,
            fg_color="#66785F",
            hover_color="#e0e0e0",
            command=self.toggle_password_visibility
        )
        self.show_pass_button.place(relx=0.9, rely=0.5, anchor="center")

        self.register_btn = CTkButton(
            self.container,
            text="Register",
            font=("Helvetica", 14, "bold"),
            width=320,
            height=50,
            corner_radius=10,
            command=self.register
        )
        self.register_btn.pack(pady=(20, 20))

        self.login_frame = CTkFrame(self.container, fg_color="transparent")
        self.login_frame.pack()

        CTkLabel(
            self.login_frame,
            text="Already have an account?",
            font=("Helvetica", 12),
            text_color="#666666"
        ).pack(side="left", padx=(0, 5))

        CTkButton(
            self.login_frame,
            text="Login",
            font=("Helvetica", 12, "bold"),
            fg_color="transparent",
            text_color="#2d2d2d",
            hover_color="#efefef",
            width=50,
            command=self.login_open
        ).pack(side="left")

    def login_open(self):
        from login import ModernLoginPage
        self.root.destroy() 
        login_app = ModernLoginPage() 
        login_app.run() 

    def validate_fields(self):

        if not self.name.get():
            messagebox.showerror("Error", "Please enter your name")
            return False
        if not self.email.get() or '@' not in self.email.get():
            messagebox.showerror("Error", "Please enter a valid email address")
            return False
        if not self.contact.get() or len(self.contact.get()) < 10:
            messagebox.showerror("Error", "Please enter a valid contact number")
            return False
        if not self.password.get() or len(self.password.get()) < 6:
            messagebox.showerror("Error", "Password must be at least 6 characters long")
            return False
        return True

    def register(self):
        if self.validate_fields():
            messagebox.showinfo("Success", "Registration successful!")
            self.clear_fields()

    def clear_fields(self):
        self.name.delete(0, 'end')
        self.email.delete(0, 'end')
        self.contact.delete(0, 'end')
        self.password.delete(0, 'end')

    def run(self):
        self.root.mainloop()

if __name__ == "__main__":
    app = ModernRegistrationPage()
    app.run()