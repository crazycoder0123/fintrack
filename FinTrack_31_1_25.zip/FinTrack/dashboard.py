import customtkinter as ctk
from tkinter import messagebox
from PIL import Image
import sqlite3
from datetime import datetime

class FinTrack:
    def __init__(self):
        ctk.set_appearance_mode("light")
        ctk.set_default_color_theme("green")

        self.root = ctk.CTk()
        self.root.geometry('1200x700+150+50')
        self.root.title('FinTrack Dashboard')

        self.database_setup()

        self.main_container = ctk.CTkFrame(self.root, fg_color="#ffffff")
        self.main_container.pack(fill="both", expand=True)

        self.create_sidebar()
        self.create_main_content()

        self.show_dashboard()

    def database_setup(self):
        self.conn = sqlite3.connect("fintrack.db")
        self.cursor = self.conn.cursor()
        
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                type TEXT NOT NULL,
                category TEXT NOT NULL,
                amount REAL NOT NULL,
                description TEXT,
                date TEXT NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        """)
        self.conn.commit()

    def create_sidebar(self):
        self.sidebar = ctk.CTkFrame(self.main_container, fg_color="#f0f0f0", width=250)
        self.sidebar.pack(side="left", fill="y", padx=0, pady=0)
        
        try:
            self.logo = ctk.CTkImage(Image.open('img\\logo.png'), size=(80, 80))
            ctk.CTkLabel(self.sidebar, image=self.logo, text="").pack(pady=(30, 20))
        except:
            ctk.CTkLabel(self.sidebar, text="FinTrack", 
                        font=("Helvetica", 20, "bold")).pack(pady=(30, 20))
        
        nav_buttons = [
            ("Dashboard", self.show_dashboard),
            ("Income", self.show_income),
            ("Expenses", self.show_expenses),
            ("Budget", self.show_budget),
            ("Reports", self.show_reports),
            ("Settings", self.show_settings),
        ]

        for text, command in nav_buttons:
            ctk.CTkButton(
                self.sidebar,
                text=text,
                font=("Helvetica", 14),
                fg_color="transparent",
                text_color="#2d2d2d",
                hover_color="#e0e0e0",
                anchor="w",
                width=200,
                height=40,
                command=command
            ).pack(pady=5, padx=20)

        ctk.CTkButton(
            self.sidebar,
            text="Logout",
            font=("Helvetica", 14),
            fg_color="#66785F",
            text_color="#ffffff",
            hover_color="#4a5745",
            width=200,
            height=40,
            command=self.logout
        ).pack(side="bottom", pady=20, padx=20)

    def create_main_content(self):
        self.content = ctk.CTkFrame(self.main_container, fg_color="#ffffff")
        self.content.pack(side="right", fill="both", expand=True, padx=20, pady=20)

    def get_transactions_summary(self):
        self.cursor.execute("""
            SELECT 
                COALESCE(SUM(CASE WHEN type = 'income' THEN amount ELSE 0 END), 0) as total_income,
                COALESCE(SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END), 0) as total_expense
            FROM transactions
        """)
        income, expense = self.cursor.fetchone()
        return {
            "total_income": income,
            "total_expense": expense,
            "total_balance": income - expense
        }

    def format_amount(self, amount):
        return f"Rs. {amount:,.2f}"

    def create_transaction_row(self, parent, transaction, show_type=True):
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=20, pady=5)
        
        ctk.CTkLabel(
            row,
            text=transaction['date'],
            font=("Helvetica", 12),
            text_color="#2d2d2d"
        ).pack(side="left", expand=True)
        
        ctk.CTkLabel(
            row,
            text=transaction['category'],
            font=("Helvetica", 12),
            text_color="#2d2d2d"
        ).pack(side="left", expand=True)
        
        if show_type:
            ctk.CTkLabel(
                row,
                text=transaction['type'].title(),
                font=("Helvetica", 12),
                text_color="#2d2d2d"
            ).pack(side="left", expand=True)
        
        ctk.CTkLabel(
            row,
            text=transaction['description'],
            font=("Helvetica", 12),
            text_color="#2d2d2d"
        ).pack(side="left", expand=True)
        
        amount_color = "#4CAF50" if transaction['type'] == 'income' else "#F44336"
        ctk.CTkLabel(
            row,
            text=self.format_amount(transaction['amount']),
            font=("Helvetica", 12, "bold"),
            text_color=amount_color
        ).pack(side="left", expand=True)
        
        if not show_type:  # Show actions only in specific transaction pages
            actions_frame = ctk.CTkFrame(row, fg_color="transparent")
            actions_frame.pack(side="left", expand=True)
            
            ctk.CTkButton(
                actions_frame,
                text="Edit",
                width=60,
                height=25,
                font=("Helvetica", 12)
            ).pack(side="left", padx=5)
            
            ctk.CTkButton(
                actions_frame,
                text="Delete",
                width=60,
                height=25,
                fg_color="#FF5252",
                hover_color="#FF1744",
                font=("Helvetica", 12),
                command=lambda: self.delete_transaction(transaction['id'])
            ).pack(side="left", padx=5)

    def delete_transaction(self, transaction_id):
        if messagebox.askyesno("Delete Transaction", "Are you sure you want to delete this transaction?"):
            self.cursor.execute("DELETE FROM transactions WHERE id = ?", (transaction_id,))
            self.conn.commit()
            messagebox.showinfo("Success", "Transaction deleted successfully!")
            self.show_income()  # Refresh the current view

    def show_dashboard(self):
        self.clear_content()
        
        header = ctk.CTkFrame(self.content, fg_color="transparent")
        header.pack(fill="x", pady=(0, 20))
        
        ctk.CTkLabel(
            header,
            text="Dashboard",
            font=("Helvetica", 24, "bold"),
            text_color="#2d2d2d"
        ).pack(side="left")
        
        ctk.CTkLabel(
            header,
            text=datetime.now().strftime("%B %d, %Y"),
            font=("Helvetica", 14),
            text_color="#666666"
        ).pack(side="right")

        # Get summary data
        summary = self.get_transactions_summary()
        
        cards = ctk.CTkFrame(self.content, fg_color="transparent")
        cards.pack(fill="x", pady=10)
        
        summary_data = [
            ("Total Balance", self.format_amount(summary['total_balance']), "#e8f5e9"),
            ("Total Income", self.format_amount(summary['total_income']), "#e3f2fd"),
            ("Total Expenses", self.format_amount(summary['total_expense']), "#fbe9e7")
        ]
        
        for title, amount, color in summary_data:
            card = ctk.CTkFrame(cards, fg_color=color, corner_radius=10)
            card.pack(side="left", expand=True, padx=10, fill="both")
            
            ctk.CTkLabel(
                card,
                text=title,
                font=("Helvetica", 14),
                text_color="#666666"
            ).pack(pady=(15, 5), padx=15)
            
            ctk.CTkLabel(
                card,
                text=amount,
                font=("Helvetica", 24, "bold"),
                text_color="#2d2d2d"
            ).pack(pady=(0, 15), padx=15)

        # Recent Transactions
        transactions = ctk.CTkFrame(self.content, fg_color="#f8f9fa", corner_radius=10)
        transactions.pack(fill="both", expand=True, pady=20)
        
        ctk.CTkLabel(
            transactions,
            text="Recent Transactions",
            font=("Helvetica", 18, "bold"),
            text_color="#2d2d2d"
        ).pack(pady=15, padx=20, anchor="w")
        
        # Headers
        headers = ctk.CTkFrame(transactions, fg_color="transparent")
        headers.pack(fill="x", padx=20)
        
        header_titles = ["Date", "Category", "Type", "Description", "Amount"]
        for title in header_titles:
            ctk.CTkLabel(
                headers,
                text=title,
                font=("Helvetica", 12, "bold"),
                text_color="#666666"
            ).pack(side="left", expand=True)
        
        # Fetch recent transactions
        self.cursor.execute("""
            SELECT id, date, category, type, description, amount 
            FROM transactions 
            ORDER BY date DESC 
            LIMIT 10
        """)
        recent_transactions = [
            {
                'id': row[0], 'date': row[1], 'category': row[2],
                'type': row[3], 'description': row[4], 'amount': row[5]
            }
            for row in self.cursor.fetchall()
        ]
        
        for transaction in recent_transactions:
            self.create_transaction_row(transactions, transaction)

    def show_income(self):
        self.clear_content()
        
        header = ctk.CTkFrame(self.content, fg_color="transparent")
        header.pack(fill="x", pady=(0, 20))
        
        ctk.CTkLabel(
            header,
            text="Income",
            font=("Helvetica", 24, "bold"),
            text_color="#2d2d2d"
        ).pack(side="left")
        
        ctk.CTkButton(
            header,
            text="+ Add Income",
            font=("Helvetica", 14),
            width=120,
            height=40,
            corner_radius=20,
            command=self.show_add_income_form
        ).pack(side="right")

        income_frame = ctk.CTkFrame(self.content, fg_color="#f8f9fa", corner_radius=10)
        income_frame.pack(fill="both", expand=True)
        
        # Add total income summary
        summary_frame = ctk.CTkFrame(income_frame, fg_color="transparent")
        summary_frame.pack(fill="x", padx=20, pady=15)
        
        self.cursor.execute("""
            SELECT COALESCE(SUM(amount), 0) 
            FROM transactions 
            WHERE type = 'income'
        """)
        total_income = self.cursor.fetchone()[0]
        
        ctk.CTkLabel(
            summary_frame,
            text="Total Income:",
            font=("Helvetica", 16, "bold"),
            text_color="#2d2d2d"
        ).pack(side="left")
        
        ctk.CTkLabel(
            summary_frame,
            text=self.format_amount(total_income),
            font=("Helvetica", 16, "bold"),
            text_color="#4CAF50"
        ).pack(side="right")
        
        # Headers for transaction list
        headers = ctk.CTkFrame(income_frame, fg_color="transparent")
        headers.pack(fill="x", padx=20, pady=15)
        
        header_titles = ["Date", "Category", "Description", "Amount", "Actions"]
        for title in header_titles:
            ctk.CTkLabel(
                headers,
                text=title,
                font=("Helvetica", 12, "bold"),
                text_color="#666666"
            ).pack(side="left", expand=True)

        # Create scrollable frame for transactions
        transactions_container = ctk.CTkScrollableFrame(income_frame, fg_color="transparent")
        transactions_container.pack(fill="both", expand=True, padx=20, pady=(0, 20))

        try:
            # Fetch only income transactions
            self.cursor.execute("""
                SELECT id, date, category, description, amount 
                FROM transactions 
                WHERE type = 'income'
                ORDER BY date DESC
            """)
            
            income_transactions = [
                {
                    'id': row[0],
                    'date': row[1],
                    'category': row[2],
                    'description': row[3],
                    'amount': row[4],
                    'type': 'income'
                }
                for row in self.cursor.fetchall()
            ]
            
            if not income_transactions:
                ctk.CTkLabel(
                    transactions_container,
                    text="No income transactions found",
                    font=("Helvetica", 12),
                    text_color="#666666"
                ).pack(pady=20)
            else:
                for transaction in income_transactions:
                    self.create_transaction_row(transactions_container, transaction, show_type=False)
                    
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load income transactions: {str(e)}")

    def show_add_income_form(self):
        form_window = ctk.CTkToplevel(self.root)
        form_window.title("Add Income")
        form_window.geometry("400x500")
        form_window.transient(self.root)
        form_window.grab_set()
        
        # Prevent interaction with main window
        form_window.focus_force()
        
        ctk.CTkLabel(
            form_window,
            text="Add New Income",
            font=("Helvetica", 20, "bold")
        ).pack(pady=(20, 30))

        form_frame = ctk.CTkFrame(form_window, fg_color="transparent")
        form_frame.pack(fill="both", expand=True, padx=20)
        
        categories = ["Salary", "Freelance", "Investments", "Business", "Rent", "Other"]
        
        date_label = ctk.CTkLabel(form_frame, text="Date:", anchor="w")
        date_label.pack(fill="x", pady=(0, 5))
        date_entry = ctk.CTkEntry(form_frame, placeholder_text="DD-MM-YYYY")
        date_entry.pack(fill="x", pady=(0, 15))
        date_entry.insert(0, datetime.now().strftime("%d-%m-%Y"))
        
        category_label = ctk.CTkLabel(form_frame, text="Category:", anchor="w")
        category_label.pack(fill="x", pady=(0, 5))
        category_dropdown = ctk.CTkOptionMenu(form_frame, values=categories)
        category_dropdown.pack(fill="x", pady=(0, 15))
        
        amount_label = ctk.CTkLabel(form_frame, text="Amount:", anchor="w")
        amount_label.pack(fill="x", pady=(0, 5))
        amount_entry = ctk.CTkEntry(form_frame, placeholder_text="Enter amount")
        amount_entry.pack(fill="x", pady=(0, 15))
        
        description_label = ctk.CTkLabel(form_frame, text="Description:", anchor="w")
        description_label.pack(fill="x", pady=(0, 5))
        description_entry = ctk.CTkEntry(form_frame, placeholder_text="Enter description")
        description_entry.pack(fill="x", pady=(0, 15))
        
        def save_income():
            try:
                # Validate inputs
                if not date_entry.get() or not amount_entry.get() or not description_entry.get():
                    raise ValueError("Please fill in all fields")
                
                amount = float(amount_entry.get())
                if amount <= 0:
                    raise ValueError("Amount must be greater than zero")
                    
                category = category_dropdown.get()
                description = description_entry.get()
                date = date_entry.get()
                
                # Validate date format
                try:
                    datetime.strptime(date, "%d-%m-%Y")
                except ValueError:
                    raise ValueError("Invalid date format. Please use DD-MM-YYYY")
                
                self.cursor.execute("""
                    INSERT INTO transactions (type, category, amount, description, date)
                    VALUES (?, ?, ?, ?, ?)
                """, ("income", category, amount, description, date))
                
                self.conn.commit()
                messagebox.showinfo("Success", "Income added successfully!")
                form_window.destroy()
                self.show_income()
            except ValueError as ve:
                messagebox.showerror("Error", str(ve))
            except Exception as e:
                messagebox.showerror("Error", f"An error occurred: {str(e)}")
        
        button_frame = ctk.CTkFrame(form_window, fg_color="transparent")
        button_frame.pack(fill="x", padx=20, pady=20)
        
        ctk.CTkButton(
            button_frame,
            text="Cancel",
            width=100,
            fg_color="#e0e0e0",
            text_color="#2d2d2d",
            hover_color="#c0c0c0",
            command=form_window.destroy
        ).pack(side="left", padx=5)
        
        ctk.CTkButton(
            button_frame,
            text="Save",
            width=100,
            command=save_income
        ).pack(side="right", padx=5)

    def show_expenses(self):
        self.clear_content()
        
        header = ctk.CTkFrame(self.content, fg_color="transparent")
        header.pack(fill="x", pady=(0, 20))
        
        ctk.CTkLabel(
            header,
            text="Expenses",
            font=("Helvetica", 24, "bold"),
            text_color="#2d2d2d"
        ).pack(side="left")
        
        ctk.CTkButton(
            header,
            text="+ Add Expense",
            font=("Helvetica", 14),
            width=120,
            height=40,
            corner_radius=20
        ).pack(side="right")

        expense_frame = ctk.CTkFrame(self.content, fg_color="#f8f9fa", corner_radius=10)
        expense_frame.pack(fill="both", expand=True)
        
        headers = ctk.CTkFrame(expense_frame, fg_color="transparent")
        headers.pack(fill="x", padx=20, pady=15)
        
        header_titles = ["Date", "Category", "Description", "Amount", "Actions"]
        for title in header_titles:
            ctk.CTkLabel(
                headers,
                text=title,
                font=("Helvetica", 12, "bold"),
                text_color="#666666"
            ).pack(side="left", expand=True)

    def show_budget(self):
        self.clear_content()
        ctk.CTkLabel(
            self.content,
            text="Budget",
            font=("Helvetica", 24, "bold"),
            text_color="#2d2d2d"
        ).pack(pady=20)

    def show_reports(self):
        self.clear_content()
        ctk.CTkLabel(
            self.content,
            text="Reports",
            font=("Helvetica", 24, "bold"),
            text_color="#2d2d2d"
        ).pack(pady=20)

    def show_settings(self):
        self.clear_content()
        ctk.CTkLabel(
            self.content,
            text="Settings",
            font=("Helvetica", 24, "bold"),
            text_color="#2d2d2d"
        ).pack(pady=20)

    def clear_content(self):
        for widget in self.content.winfo_children():
            widget.destroy()

    def logout(self):
        if messagebox.askyesno("Logout", "Are you sure you want to logout?"):
            self.root.destroy()
            try:
                from main import FinTrack
                login = FinTrack()
                login.run()
            except ImportError:
                messagebox.showinfo("Info", "Logged out successfully")

    def run(self):
        self.root.mainloop()

if __name__ == "__main__":
    app = FinTrack()
    app.run()