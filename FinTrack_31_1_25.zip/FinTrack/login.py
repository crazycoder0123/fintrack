
from customtkinter import *
from tkinter import messagebox
from PIL import Image
from registration import ModernRegistrationPage

class ModernLoginPage:
    def __init__(self):
        set_appearance_mode("light")
        set_default_color_theme("green")

        self.root = CTk()
        self.root.geometry('500x600+500+100')
        self.root.title('FinTrack')
        self.root.resizable(False, False)

        self.container = CTkFrame(self.root, fg_color="#ffffff")
        self.container.pack(fill="both", expand=True)

        self.show_password = False
        self.create_login_form()

    def toggle_password_visibility(self):
        self.show_password = not self.show_password
        if self.show_password:
            self.password.configure(show="")
            self.show_pass_button.configure(text="🔒")  
        else:
            self.password.configure(show="●")
            self.show_pass_button.configure(text="👁️")
        

    def create_login_form(self):
        self.logo = CTkImage(Image.open('img\\logo.png'), size=(120, 120))
        self.logo_label = CTkLabel(self.container, image=self.logo, text='')
        self.logo_label.pack(pady=(60, 20))

        CTkLabel(
            self.container,
            text="Welcome Back!",
            font=("Helvetica", 28, "bold"),
            text_color="#2d2d2d"
        ).pack(pady=(0, 10))

        CTkLabel(
            self.container,
            text="Please login to your account",
            font=("Helvetica", 14),
            text_color="#666666"
        ).pack(pady=(0, 30))

        self.email = CTkEntry(
            self.container,
            placeholder_text="Email or Phone Number",
            width=320,
            height=50,
            font=("Helvetica", 12),
            border_width=2,
            corner_radius=10
        )
        self.email.pack(pady=(0, 20))

        self.password_frame = CTkFrame(self.container, fg_color="transparent")
        self.password_frame.pack(pady=(0, 10))

        self.password = CTkEntry(
            self.password_frame,
            placeholder_text="Password",
            width=320,
            height=50,
            font=("Helvetica", 12),
            border_width=2,
            corner_radius=10,
            show="●"
        )
        self.password.pack(side="left")

        self.show_pass_button = CTkButton(
            self.password,
            text="👁️",
            width=20,
            height=25,
            fg_color="#66785F",
            hover_color="#e0e0e0",
            command=self.toggle_password_visibility
        )
        self.show_pass_button.place(relx=0.9, rely=0.5, anchor="center")

        self.forgot = CTkButton(
            self.container,
            text="Forgot Password?",
            font=("Helvetica", 12),
            fg_color="transparent",
            text_color="#666666",
            hover_color="#efefef",
            width=50
        )
        self.forgot.pack(pady=(0, 20))

        self.login_btn = CTkButton(
            self.container,
            text="Login",
            font=("Helvetica", 14, "bold"),
            width=320,
            height=50,
            corner_radius=10,
        )
        self.login_btn.pack(pady=(0, 20))

        self.signup_frame = CTkFrame(self.container, fg_color="transparent")
        self.signup_frame.pack()

        CTkLabel( 
            self.signup_frame,
            text="Don't have an account?",
            font=("Helvetica", 12),
            text_color="#666666"
        ).pack(side="left", padx=(0, 5))

        CTkButton(
            self.signup_frame,
            text="Sign Up",
            font=("Helvetica", 12, "bold"),
            fg_color="transparent",
            text_color="#2d2d2d",
            hover_color="#efefef",
            width=50,
            command=self.registratio_open
        ).pack(side="left")

    def registratio_open(self):
        self.root.destroy() 
        registration_app = ModernRegistrationPage() 
        registration_app.run() 

    def login(self):
        email = self.email.get()
        password = self.password.get()
        
        if email and password:
            messagebox.showinfo("Success", "Login successful!")
        else:
            messagebox.showerror("Error", "Please fill in all fields")

    def run(self):
        self.root.mainloop()

if __name__ == "__main__":
    app = ModernLoginPage()
    app.run()