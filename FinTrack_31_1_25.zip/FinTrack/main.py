from customtkinter import *
from tkinter import messagebox
from PIL import Image
import sqlite3


class FinTrack:
    def __init__(self):
        set_appearance_mode("light")
        set_default_color_theme("green")

        self.root = CTk()
        self.root.geometry('500x700+500+50')
        self.root.title('FinTrack')
        self.root.resizable(False, False)

        self.container = CTkFrame(self.root, fg_color="#ffffff")
        self.container.pack(fill="both", expand=True)

        self.show_password = False

        self.database_setup()

        self.create_login_form()

    def database_setup(self):
        # Initialize the database connection and cursor
        self.conn = sqlite3.connect("fintrack.db")
        self.cursor = self.conn.cursor()
        self.cursor.execute(""" 
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT UNIQUE NOT NULL,
                contact TEXT NOT NULL,
                password TEXT NOT NULL
            )
        """)
        self.conn.commit()
    
    def toggle_password_visibility(self, entry, button):
        self.show_password = not self.show_password
        if self.show_password:
            entry.configure(show="")
            button.configure(text="🔒")
        else:
            entry.configure(show="●")
            button.configure(text="👁️")

    def switch_to_registration(self):
        self.clear_form()
        self.create_registration_form()

    def switch_to_login(self):
        self.clear_form()
        self.create_login_form()

    def dashboard_open(self):
        from dashboard import FinTrack 
        self.root.destroy() 
        dashboard_open = FinTrack() 
        dashboard_open.run() 

    def clear_form(self):
        for widget in self.container.winfo_children():
            widget.destroy()

    def create_login_form(self):
        self.logo = CTkImage(Image.open('img\\logo.png'), size=(120, 120))
        self.logo_label = CTkLabel(self.container, image=self.logo, text='')
        self.logo_label.pack(pady=(60, 20))

        CTkLabel(
            self.container,
            text="Welcome Back!",
            font=("Helvetica", 28, "bold"),
            text_color="#2d2d2d"
        ).pack(pady=(0, 10))

        CTkLabel(
            self.container,
            text="Please login to your account",
            font=("Helvetica", 14),
            text_color="#666666"
        ).pack(pady=(0, 30))

        self.email = CTkEntry(
            self.container,
            placeholder_text="Email or Phone Number",
            width=320,
            height=50,
            font=("Helvetica", 12),
            border_width=2,
            corner_radius=10
        )
        self.email.pack(pady=(0, 20))

        self.password_frame = CTkFrame(self.container, fg_color="transparent")
        self.password_frame.pack(pady=(0, 10))

        self.password = CTkEntry(
            self.password_frame,
            placeholder_text="Password",
            width=320,
            height=50,
            font=("Helvetica", 12),
            border_width=2,
            corner_radius=10,
            show="●"
        )
        self.password.pack(side="left")

        self.show_pass_button = CTkButton(
            self.password,
            text="👁️",
            width=20,
            height=25,
            fg_color="#66785F",
            hover_color="#e0e0e0",
            command=lambda: self.toggle_password_visibility(self.password, self.show_pass_button)
        )
        self.show_pass_button.place(relx=0.9, rely=0.5, anchor="center")

        self.forgot = CTkButton(
            self.container,
            text="Forgot Password?",
            font=("Helvetica", 12),
            fg_color="transparent",
            text_color="#666666",
            hover_color="#efefef",
            width=50,
            command=self.switch_to_forgot_password
        )
        self.forgot.pack(pady=(0, 20))

        self.login_btn = CTkButton(
            self.container,
            text="Login",
            font=("Helvetica", 14, "bold"),
            width=320,
            height=50,
            corner_radius=10,
            command=self.login
        )
        self.login_btn.pack(pady=(0, 20))

        self.signup_frame = CTkFrame(self.container, fg_color="transparent")
        self.signup_frame.pack()

        CTkLabel(
            self.signup_frame,
            text="Don't have an account?",
            font=("Helvetica", 12),
            text_color="#666666"
        ).pack(side="left", padx=(0, 5))

        CTkButton(
            self.signup_frame,
            text="Sign Up",
            font=("Helvetica", 12, "bold"),
            fg_color="transparent",
            text_color="#2d2d2d",
            hover_color="#efefef",
            width=50,
            command=self.switch_to_registration
        ).pack(side="left")

    def create_registration_form(self):
        self.logo = CTkImage(Image.open('img\\logo.png'), size=(120, 120))
        self.logo_label = CTkLabel(self.container, image=self.logo, text='')
        self.logo_label.pack(pady=(50, 20))

        CTkLabel(
            self.container,
            text="Create Account",
            font=("Helvetica", 28, "bold"),
            text_color="#2d2d2d"
        ).pack(pady=(0, 10))

        CTkLabel(
            self.container,
            text="Please fill in your details",
            font=("Helvetica", 14),
            text_color="#666666"
        ).pack(pady=(0, 30))

        self.name = CTkEntry(
            self.container,
            placeholder_text="Full Name",
            width=320,
            height=50,
            font=("Helvetica", 12),
            border_width=2,
            corner_radius=10
        )
        self.name.pack(pady=(0, 20))

        self.email = CTkEntry(
            self.container,
            placeholder_text="Email Address",
            width=320,
            height=50,
            font=("Helvetica", 12),
            border_width=2,
            corner_radius=10
        )
        self.email.pack(pady=(0, 20))

        self.contact = CTkEntry(
            self.container,
            placeholder_text="Contact Number",
            width=320,
            height=50,
            font=("Helvetica", 12),
            border_width=2,
            corner_radius=10
        )
        self.contact.pack(pady=(0, 20))

        self.password_frame = CTkFrame(self.container, fg_color="transparent")
        self.password_frame.pack(pady=(0, 20))

        self.password = CTkEntry(
            self.password_frame,
            placeholder_text="Password",
            width=320,
            height=50,
            font=("Helvetica", 12),
            border_width=2,
            corner_radius=10,
            show="●"
        )
        self.password.pack(side="left")

        self.show_pass_button = CTkButton(
            self.password,
            text="👁️",
            width=20,
            height=20,
            fg_color="#66785F",
            hover_color="#e0e0e0",
            command=lambda: self.toggle_password_visibility(self.password, self.show_pass_button)
        )
        self.show_pass_button.place(relx=0.9, rely=0.5, anchor="center")

        self.register_btn = CTkButton(
            self.container,
            text="Register",
            font=("Helvetica", 14, "bold"),
            width=320,
            height=50,
            corner_radius=10,
            command=self.register
        )
        self.register_btn.pack(pady=(20, 20))

        self.login_frame = CTkFrame(self.container, fg_color="transparent")
        self.login_frame.pack()

        CTkLabel(
            self.login_frame,
            text="Already have an account?",
            font=("Helvetica", 12),
            text_color="#666666"
        ).pack(side="left", padx=(0, 5))

        CTkButton(
            self.login_frame,
            text="Login",
            font=("Helvetica", 12, "bold"),
            fg_color="transparent",
            text_color="#2d2d2d",
            hover_color="#efefef",
            width=50,
            command=self.switch_to_login
        ).pack(side="left")

    def login(self):
        email = self.email.get()
        contact = self.email.get()
        password = self.password.get()

        if not email or '@' not in email:
            messagebox.showerror("Error", "Please enter a valid email address")
            return False
        elif not contact or len(contact) < 10:
            messagebox.showerror("Error", "Please enter a valid contact number")
            return False
        elif not password or len(password) < 6:
            messagebox.showerror("Error", "Password must be at least 6 characters long")
            return False
        else:
            self.cursor.execute("SELECT * FROM users WHERE (email = ? OR contact = ?) AND password = ?", (email, contact, password))
            user = self.cursor.fetchone()
            if user:
                messagebox.showinfo("Success", f"Welcome, {user[1]}!")
                self.dashboard_open()
            else:
                messagebox.showerror("Error", "Invalid email or password")

    def register(self):
        name = self.name.get()
        email = self.email.get()
        contact = self.contact.get()
        password = self.password.get()

        if not name:
            messagebox.showerror("Error", "Please enter your name")
            return False
        elif not email or '@' not in email:
            messagebox.showerror("Error", "Please enter a valid email address")
            return False
        elif not contact or len(contact) < 10:
            messagebox.showerror("Error", "Please enter a valid contact number")
            return False
        elif not password or len(password) < 6:
            messagebox.showerror("Error", "Password must be at least 6 characters long")
            return False
        else:
            self.cursor.execute("INSERT INTO users (name, email, contact, password) VALUES (?, ?, ?, ?)",
                                (name, email, contact, password))
            self.conn.commit()
            messagebox.showinfo("Success", "Registration successful!")
            self.clear_fields()
            self.switch_to_login()

    def clear_fields(self):
        self.name.delete(0, 'end')
        self.email.delete(0, 'end')
        self.contact.delete(0, 'end')
        self.password.delete(0, 'end')

    def switch_to_forgot_password(self):
        self.clear_form()
        self.create_forgot_password_form()

    def create_forgot_password_form(self):
        self.logo = CTkImage(Image.open('img\\logo.png'), size=(120, 120))
        self.logo_label = CTkLabel(self.container, image=self.logo, text='')
        self.logo_label.pack(pady=(50, 20))

        CTkLabel(
            self.container,
            text="Forgot Password?",
            font=("Helvetica", 28, "bold"),
            text_color="#2d2d2d"
        ).pack(pady=(0, 10))

        CTkLabel(
            self.container,
            text="Please enter your email or contact number to reset your password.",
            font=("Helvetica", 14),
            text_color="#666666"
        ).pack(pady=(0, 30))

        self.email_or_contact = CTkEntry(
            self.container,
            placeholder_text="Email or Contact Number",
            width=320,
            height=50,
            font=("Helvetica", 12),
            border_width=2,
            corner_radius=10
        )
        self.email_or_contact.pack(pady=(0, 20))

        self.new_password = CTkEntry(
            self.container,
            placeholder_text="New Password",
            width=320,
            height=50,
            font=("Helvetica", 12),
            border_width=2,
            corner_radius=10,
            show="●"
        )
        self.new_password.pack(pady=(0, 20))

        # Confirm Password Field
        self.confirm_password = CTkEntry(
            self.container,
            placeholder_text="Confirm Password",
            width=320,
            height=50,
            font=("Helvetica", 12),
            border_width=2,
            corner_radius=10,
            show="●"
        )
        self.confirm_password.pack(pady=(0, 20))

        self.submit_button = CTkButton(
            self.container,
            text="Submit",
            font=("Helvetica", 14, "bold"),
            width=320,
            height=50,
            corner_radius=10,
            command=self.reset_password
        )
        self.submit_button.pack(pady=(20, 20))

    def reset_password(self):
        email_or_contact = self.email_or_contact.get()
        new_password = self.new_password.get()
        confirm_password = self.confirm_password.get()

        if not email_or_contact or not new_password or not confirm_password:
            messagebox.showerror("Error", "Please fill in all fields.")
            return

        if new_password != confirm_password:
            messagebox.showerror("Error", "Passwords do not match.")
            return

        if len(new_password) < 6:
            messagebox.showerror("Error", "Password must be at least 6 characters long.")
            return

        self.cursor.execute("SELECT * FROM users WHERE email = ? OR contact = ?", (email_or_contact, email_or_contact))
        user = self.cursor.fetchone()

        if user:
            self.cursor.execute("UPDATE users SET password = ? WHERE email = ? OR contact = ?", (new_password, email_or_contact, email_or_contact))
            self.conn.commit()
            messagebox.showinfo("Success", "Your password has been reset successfully.")
            self.switch_to_login()
        else:
            messagebox.showerror("Error", "User not found. Please check your email/contact or register a new account.")

    
    def run(self):
        self.root.mainloop()


if __name__ == "__main__":
    app = FinTrack()
    app.run()
